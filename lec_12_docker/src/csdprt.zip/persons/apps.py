from django.apps import AppConfig


class PersonsConfig(AppConfig):
    name = 'persons'
