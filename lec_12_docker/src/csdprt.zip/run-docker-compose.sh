docker-compose up --build --detach

