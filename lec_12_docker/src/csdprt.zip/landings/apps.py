from django.apps import AppConfig


class LandingsConfig(AppConfig):
    name = 'landings'
